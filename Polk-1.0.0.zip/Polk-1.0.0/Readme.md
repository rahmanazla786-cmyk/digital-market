# Polk – Free Bootstrap Interior Design Website Template 

#### Preview

 - [Demo](https://themewagon.github.io/polk/)

#### Download
 - [Download from ThemeWagon](https://themewagon.com/themes/polk/)

## Getting Started

1. Clone Repository
```
git clone https://github.com/themewagon/polk.git
```

## Author 
```
Design and code are completely written by the HTML Design development team. 
```

## License

 - Design and Code is Copyright &copy; [HTML Design](https://html.design/)
 - Licensed under [MIT]
 - Distributed by [ThemeWagon](https://themewagon.com)
